
#include <Arduino.h>

#ifndef F_CPU 
#define F_CPU 16000000L
#endif


#if defined (MPINO_8A4R_S)
	void M8A4RS(); 	
#elif defined (MPINO_8A8R_S)
	void M8A8RS();
#elif defined (MPINO_16A16R)
	void M16A16R();
#elif defined (MPINO_8A8R)
	void M8A8R();
#endif



#if defined (MPINO_8A4R_S) or defined (MPINO_8A8R_S) or defined (MPINO_16A16R)
	void HCNT0_ENABLE(); 
	void HCNT1_ENABLE();
	void ENCO_ENABLE();
	void PWM_SET(uint16_t Value);
	void __HCNT0();
	void __HCNT1();
	void __ENCO();
	extern uint32_t HCNT0, HCNT1, ENCO;
	extern bool HCNT0_EN;
//#elif defined (MPINO_8A8R)

#endif 



#include "ISEG.h"
#include "CLCD.h"
#include "WATCHDOG.h"
#include "IPID.h"
#include "IPWM.h"
#include "NTEMP.h"
#include "DHT.h"
#include "DS3231.h"
#include "IDAC.h"
#include "IADC.h"
#include "ITIMER.h"
#include "MODBUS_RTU.h"



