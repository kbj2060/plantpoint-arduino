VER1.49 	2021-09-24 : IADC 라이브러리에 SPS값을 수정할 수 있도록 수정하였습니다.
VER1.48 	2021-09-07 : 제품별 핀번호가 수정되었습니다.
VER1.47 	2021-09-01 : IDAC 기능을 수정하였습니다. 
VER1.45 	2021-08-13 : IADC 라이브러리에 오류가 있던 점을 수정 및 MPINO STUDIO 예제가 수정되었습니다. 
VER1.44 	2021-08-05 : MPINO 시리즈 제품도 IADC함수를 사용할 수 있게 수정 및 예제파일이 수정되었습니다. 
VER1.43 	2021-07-30 : FASTPWM함수 이름을 FDPWM으로 수정되었습니다.
VER1.42 	2021-07-29 : ILIB라이브러리 Ladder프로그램에 맞추어 함수이름 및 예제파일 수정되었습니다.
VER1.41 	2021-07-22 : ILIB라이브러리의 IADC 함수 이름이 변경되었습니다.
VER1.40 	2021-07-12 : ILIB라이브러리의 예제파일 및 IADC 알고리즘이 수정되었습니다.
VER1.39 	2021-07-09 : ILIB라이브러리의 PWM, FASTPWM, NPWM 버그가 수정되었습니다.
VER1.38 	2021-07-05 : FASTPWM 라이브러리와 NPWM 라이브러리를 추가하였습니다.
VER1.37  2021-06-25 : MPAINOX시리즈 관련 라이브러리를 수정하였습니다.
VER1.35  2021-05-24 : ModbusSlave 시리얼속도를 9600에서 115200까지 할 수 있게 허용하였습니다.
VER1.34	2021-05-20
이 라이브러리는 ISEG, PWM, NPWM, FASTPWM, PWMOFF, TCNTSETUP, 
ICNT, ICNT1, DHT, DS3231, CLCD, IADC, IDAC, ITIMER, MODBUS 라이브러리를 포함하고 있습니다.
